/* 
    File: requestchannel.C

    Author: R. Bettati
            Department of Computer Science
            Texas A&M University
    Date  : 2012/07/11

*/

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

    /* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include <cassert>
#include <cstring>
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#include <errno.h>

#include "reqchannel.h"

using namespace std;

int string2int(string s)
{
	int sum = 0;
	for(int i = 0; i < s.length(); i++)
	{
		int trans = s[i];
		sum += trans;
	}
	return sum;
}

/*--------------------------------------------------------------------------*/
/* DATA STRUCTURES */ 
/*--------------------------------------------------------------------------*/

    /* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* CONSTANTS */
/*--------------------------------------------------------------------------*/

    /* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* FORWARDS */
/*--------------------------------------------------------------------------*/

    /* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* PRIVATE METHODS FOR CLASS   R e q u e s t C h a n n e l  */
/*--------------------------------------------------------------------------*/

/*char * RequestChannel::pipe_name(Mode _mode) {
  string pname = "fifo_" + my_name;

  if (my_side == CLIENT_SIDE) {
    if (_mode == READ_MODE) 
      pname += "a";
    else
      pname += "b";
  } else {
    // SERVER_SIDE 
    if (_mode == READ_MODE) 
      pname += "b";
    else 
      pname += "a";
  }
  char * result = new char[pname.size()+1];
  strncpy(result, pname.c_str(), pname.size()+1);
  return result;
}

void RequestChannel::open_write_pipe(char * _pipe_name) {

    //cout << "mkfifo write pipe [" << _pipe_name << "]\n" << flush;

  if (mkfifo(_pipe_name, 0600) < 0) {
    if (errno != EEXIST) {
      perror("Error creating pipe for writing; exit program");
      exit(1);
    }
  }

   //cout << "open write pipe [" << _pipe_name << "]\n" << flush;

  wfd = open(_pipe_name, O_WRONLY);
  if (wfd < 0) {
    perror("Error opening pipe for writing; exit program");
    exit(1);
  }

    //cout << "done opening write pipe [" << _pipe_name << "]\n" << flush;

}

void RequestChannel::open_read_pipe(char * _pipe_name) {

    //cout << "mkfifo read pipe [" << _pipe_name << "]\n" << flush;

  if (mkfifo(_pipe_name, 0600) < 0) {
    if (errno != EEXIST) {
      perror("Error creating pipe for writing; exit program");
      exit(1);
    }
  }

    //cout << "open read pipe [" << _pipe_name << "]\n" << flush;

  rfd = open(_pipe_name, O_RDONLY);
  if (rfd < 0) {
    perror("Error opening pipe for reading; exit program");
    exit(1);
  }

    //cout << "done opening read pipe [" << _pipe_name << "]\n" << flush;

}*/

/*--------------------------------------------------------------------------*/
/* CONSTRUCTOR/DESTRUCTOR FOR CLASS   R e q u e s t C h a n n e l  */
/*--------------------------------------------------------------------------*/

RequestChannel::RequestChannel(const string _name, const Side _side) : my_name(_name), my_side(_side) {
	shkey = string2int(_name);
  if (_side == SERVER_SIDE) {
	//cerr << "Creating server channel " << _name << " with shkey " << shkey << endl;
	//cout << "shkey server is : " << shkey << "for name : " << _name << endl;
	shmid = shmget(shkey, 100, IPC_CREAT | 0666);
	if(shmid < 0)
	{
		cerr << "Failed to create shared memory" << endl;
	}
	//cerr << "Got shmid " << shmid << endl;
	data = (char*) shmat(shmid, NULL, 0);
	if (data == (char*) (-1))
	{
		cerr << "Attach failed server" << endl;
	}
	string start = "start";
	strcpy(data, start.c_str());
	}
	else{
		//cerr << "Creating client channel " << _name << " with shkey " << shkey << endl;
		//cerr << "client channel name is : " << _name << endl;
		shmid = -1;
		//cout << "shkey client is : " << shkey << endl;
		while(shmid < 0)
		{
			shmid = shmget(shkey, 100, 0666);
			if(shmid < 0)
			{
				//cerr << "Failed to find shared memory" << endl;
			}
			//cerr << "Got shmid client" << shmid << endl;
			data = (char*) shmat(shmid, NULL, 0);
			if (data == (char*) (-1))
			{
				//cerr << "Attach failed client shmid " << shmid << endl;
			}
			if (shmid > 0)
			{
				break;
			}
		}
	}
}

RequestChannel::~RequestChannel() {
	//if(my_side == SERVER_SIDE)
	//	cerr << "I am server " << my_name << endl;
	//else
	//	cerr << "I am client " << my_name << endl;
  int quit = shmdt(data); 
  data = NULL;
  if(my_side == SERVER_SIDE)
  {
	  int del = shmctl(shmid, IPC_RMID, NULL);
	  if(del != 0)
	  {
		  cerr << "Remove failed" << endl;
	  }
	  else
	  {
		  //cerr << "remove success!" << endl;
	  }
  }
  if(quit == -1)
  {
	  cerr << "Detach failed shmid " << shmid << endl;
  }
  else
  {
	  //cerr << "detached!" << endl;
  }

  //cout << "Bye y'all" << flush << endl;
}

/*--------------------------------------------------------------------------*/
/* READ/WRITE FROM/TO REQUEST CHANNELS  */
/*--------------------------------------------------------------------------*/

const int MAX_MESSAGE = 255;

string RequestChannel::send_request(string _request) {
	clientcwrite(_request);
	string s = clientcread();
	return s;
}

string RequestChannel::clientcread() {
	//cout << "(" << my_side << " " << my_name << ") reading." << endl;
	string message;
	char* ptr = data;
	string s(data);
	while(1)
	{
		s = string(data);
		if(s.compare(0, 8, "response") == 0)
		{
			ptr = ptr + 8;
			strcpy(data, ptr);
			break;
		}
	}
	s = string(data);
	//cout << "(" << my_side << " " << my_name << ") read " << s << endl;
	char flush[] = "flush";
	strcpy(data, flush);
	return s;
}

int RequestChannel::clientcwrite(string _msg) {
	string csend = "request" + _msg;
	strcpy(data, csend.c_str());
	//cout << "sent " << csend << "to " << &data << endl;
	//  cout << "(" << my_name << ") done writing." << endl;
}

string RequestChannel::servercread() {
	//if(data != NULL)
	//{
	//cout << "(" << my_side << " " << my_name << ") reading." << endl;
	string message;
	char* ptr = data;
	//cerr << "reading from " << &data << endl;
	string s;
	while(1)
	{
		//strcpy(msg, data);
		s = string(data);
		if(s.compare(0, 7, "request") == 0)
		{
			ptr = ptr + 7;
			strcpy(data, ptr);
			break;
		}
	}
	message = string(data);
	//cout << "(" << my_side << " " << my_name << ") read " << s << endl;
	char flush[] = "flush";
	strcpy(data, flush);
	return message;
	
}

int RequestChannel::servercwrite(string _msg) {
	string send = "response" + _msg;
	//cerr << "Server wrote" << send << endl;
	strcpy(data, send.c_str());
	//  cout << "(" << my_name << ") done writing." << endl;
}

/*--------------------------------------------------------------------------*/
/* ACCESS THE NAME OF REQUEST CHANNEL  */
/*--------------------------------------------------------------------------*/

string RequestChannel::name() {
  return my_name;
}

/*--------------------------------------------------------------------------*/
/* ACCESS FILE DESCRIPTORS OF REQUEST CHANNEL  */
/*--------------------------------------------------------------------------*/

int RequestChannel::read_fd() {
  return rfd;
}

int RequestChannel::write_fd() {
  return wfd;
}

